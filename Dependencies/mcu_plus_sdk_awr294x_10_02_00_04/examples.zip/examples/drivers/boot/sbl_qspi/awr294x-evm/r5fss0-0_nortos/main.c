/*
 *  Copyright (C) 2018-2025 Texas Instruments Incorporated
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdlib.h>
#include "ti_drivers_config.h"
#include "ti_drivers_open_close.h"
#include "ti_board_open_close.h"
#include <drivers/bootloader.h>
#include <drivers/hsmclient.h>
#include <drivers/hsmclient/soc/awr294x/hsmRtImg.h> /* hsmRt bin   header file */

#define FW_CLIENT_ID                  (0x03)
#define GET_CACHE_ALIGNED_SIZE(x)     ((x + CacheP_CACHELINE_ALIGNMENT) & ~(CacheP_CACHELINE_ALIGNMENT - 1))

const uint8_t gHsmRtFw[HSMRT_IMG_SIZE_IN_BYTES]__attribute__((section(".rodata.hsmrt"))) = HSMRT_IMG;
extern HsmClient_t gHSMClient ;
extern Bootloader_Config gBootloaderConfig[CONFIG_BOOTLOADER_NUM_INSTANCES];
extern uint32_t gIsL3MemInitDone ;
#if defined (FIREWALL_ARRAY0_NUM_REGIONS)
extern FirewallRegionReq_t gMpuFirewallRegionConfig_0[FIREWALL_ARRAY0_NUM_REGIONS];
static MPU_FIREWALL_RegionParams orgConfig[FIREWALL_ARRAY0_NUM_REGIONS];
static HsmClient_t gFwClient ;
#endif

/*  this API is a weak function definition for keyring_init function
    which is defined in generated files if keyring module is enabled
    in syscfg
*/
__attribute__((weak)) int32_t Keyring_init(HsmClient_t *gHSMClient)
{
    return SystemP_SUCCESS;
}

/* call this API to stop the booting process and spin, do that you can connect
 * debugger, load symbols and then make the 'loop' variable as 0 to continue execution
 * with debugger connected.
 */
void loop_forever(void)
{
    volatile uint32_t loop = 1;
    while(loop);
}

#if defined (FIREWALL_ARRAY0_NUM_REGIONS)
/* Get the original L3 RAM MPU Firewall Configuration*/
static void SblQspi_getL3MpuConfig()
{
    uint32_t fwCtr = 0;
    Fwl_Return_t status = FWL_DRV_RETURN_FAILURE;
    for(fwCtr = 0U; fwCtr < FIREWALL_ARRAY0_NUM_REGIONS; fwCtr++)
    {

        orgConfig[fwCtr].id = gMpuFirewallRegionConfig_0[fwCtr].firewallId;
        orgConfig[fwCtr].regionNumber = gMpuFirewallRegionConfig_0[fwCtr].region;
        status = MPU_FIREWALL_getRegion(&orgConfig[fwCtr]);
        DebugP_assert(status == FWL_DRV_RETURN_SUCCESS);
    }
}

/* Update L3 RAM MPU Firewall settings */
static void SblQspi_updateL3MpuConfig()
{
    int32_t status ;
    FirewallReq_t FirewallReqObj;

    FirewallReqObj.regionCount = FIREWALL_ARRAY0_NUM_REGIONS;
    FirewallReqObj.FirewallRegionArr = gMpuFirewallRegionConfig_0;

    /* This requests configures CONTROLSS_CTRL region and allow all permissions to only R5FSS0_0 */
    status = HsmClient_setFirewall(&gFwClient,&FirewallReqObj,SystemP_WAIT_FOREVER);
    DebugP_assert(status == SystemP_SUCCESS);
}

/* Set back the L3 RAM MPU Firewall to original configuration */
static void SblQspi_restoreL3MpuConfig()
{
    uint32_t fwCtr = 0;
    int32_t status = SystemP_FAILURE;
    FirewallReq_t FirewallReqObj = {0};
    static FirewallRegionReq_t FirewallRegionArr[FIREWALL_ARRAY0_NUM_REGIONS] = {0};
    uint32_t  permissionAttributes[FIREWALL_ARRAY0_NUM_REGIONS] = {0U};

    for(fwCtr = 0U; fwCtr<FIREWALL_ARRAY0_NUM_REGIONS; fwCtr++)
    {
        permissionAttributes[fwCtr] = (((orgConfig[fwCtr].userExecConfig        & 0x1U) <<  0U) |
                                        ((orgConfig[fwCtr].userWriteConfig       & 0x1U) <<  1U) |
                                        ((orgConfig[fwCtr].userExecConfig        & 0x1U) <<  2U) |
                                        ((orgConfig[fwCtr].supervisorExecConfig  & 0x1U) <<  3U) |
                                        ((orgConfig[fwCtr].supervisorWriteConfig & 0x1U) <<  4U) |
                                        ((orgConfig[fwCtr].supervisorReadConfig  & 0x1U) <<  5U) |
                                        ((orgConfig[fwCtr].debugConfig           & 0x1U) <<  6U) |
                                        ((orgConfig[fwCtr].nonSecureConfig       & 0x1U) <<  7U) |
                                        ((orgConfig[fwCtr].aidxConfig            & 0x1U) <<  9U) |
                                        ((orgConfig[fwCtr].aidConfig          & 0xFFFFU) << 10U));
    }

    for(fwCtr = 0U; fwCtr<FIREWALL_ARRAY0_NUM_REGIONS; fwCtr++)
    {
        FirewallRegionArr[fwCtr].firewallId = gMpuFirewallRegionConfig_0[fwCtr].firewallId;
        FirewallRegionArr[fwCtr].region = gMpuFirewallRegionConfig_0[fwCtr].region;
        FirewallRegionArr[fwCtr].permissionAttributes = permissionAttributes[fwCtr];
        FirewallRegionArr[fwCtr].startAddress = gMpuFirewallRegionConfig_0[fwCtr].startAddress;
        FirewallRegionArr[fwCtr].endAddress = gMpuFirewallRegionConfig_0[fwCtr].endAddress;
    }

    /* Cache Writeback to ensure the FirewallRegionArr is updated in RAM*/
    CacheP_wbInv((void*)FirewallRegionArr, GET_CACHE_ALIGNED_SIZE(FIREWALL_ARRAY0_NUM_REGIONS * sizeof(FirewallRegionReq_t)), CacheP_TYPE_ALL);

    FirewallReqObj.regionCount = FIREWALL_ARRAY0_NUM_REGIONS;
    FirewallReqObj.FirewallRegionArr = FirewallRegionArr;

    status = HsmClient_setFirewall(&gFwClient,&FirewallReqObj,SystemP_WAIT_FOREVER);
    DebugP_assert(status == SystemP_SUCCESS);
}

/* Clear the L3 RAM and restore the L3 RAM MPU firewall configuration, also unregister the HSM FW client id*/
static void SblQspi_resetL3Banks()
{
    /* Reset and clear L3 RAM memory*/
    HW_WR_REG32((CSL_DSS_CTRL_U_BASE + CSL_DSS_CTRL_DSS_L3RAM_MEMINIT_START), 0xFU);

    /* Restore L3 RAM MPU Firewall Configuration*/
    SblQspi_restoreL3MpuConfig();

    /* Unregister HSM client for FW_CLIENT_ID */
    HsmClient_unregister(&gFwClient, FW_CLIENT_ID);
}

#endif


/* This function will always return true indicating that SOC is in LockStep mode.
 * Usually the SBL application decides the mode of operation based on the available
 * R5F core images in multicore image. If user wants SBL application to decide the
 * execution mode (LockStep/dual-core), SBL applicatioon needs to be recompiled
 * with below function commented.
 */
uint32_t SOC_rcmIsR5FInLockStepMode(uint32_t r5fClusterGroupId)
{
    return TRUE;
}

int main(void)
{
    int32_t status;
#if defined FIREWALL_ARRAY0_NUM_REGIONS
    uint32_t decryptAppImage = FALSE;
    uint32_t fwCtr = 0;
#endif

    Bootloader_profileReset();
    Bootloader_socConfigurePll();

    System_init();
    Bootloader_profileAddProfilePoint("System_init");

    Drivers_open();
    Bootloader_profileAddProfilePoint("Drivers_open");

    DebugP_log("\r\n");
    Bootloader_socLoadHsmRtFw(&gHSMClient, gHsmRtFw, HSMRT_IMG_SIZE_IN_BYTES);
    Bootloader_profileAddProfilePoint("LoadHsmRtFw");
    status = Keyring_init(&gHSMClient);
    DebugP_assert(status == SystemP_SUCCESS);

    DebugP_log("Starting QSPI Bootloader ... \r\n");

    status = Board_driversOpen();
    DebugP_assert(status == SystemP_SUCCESS);
    Bootloader_profileAddProfilePoint("Board_driversOpen");

    if(SystemP_SUCCESS == status)
    {
        Bootloader_BootImageInfo bootImageInfo;
        Bootloader_Params bootParams;
        Bootloader_Handle bootHandle;

        Bootloader_Params_init(&bootParams);
        Bootloader_BootImageInfo_init(&bootImageInfo);

#if defined FIREWALL_ARRAY0_NUM_REGIONS
        /* Check if appimage decryption is required. These fields are populated in sysconfig.
         * Also ensure that proper firewall config for L3 RAM is added in sysconfig for updating L3 firewall MPU that stores decrypted image
         * Note: App Image decryption will be done only if all of following conditions are met-
                1. Bootloader_socIsAuthRequired is set true i.e. device is HS-SE
                2. App-image is both encrypted and signed, i.e. in sbl sysconfig, under bootloader -
                   "Application Image Is X509 Signed" and "Decrypt Application Image" are enabled
                3. Disable Auth flag is set to FALSE
                4. FIREWALL_ARRAY0_NUM_REGIONS >=1 , i.e. SET_MPU_FIREWALL_REQUEST_0 is added in sbl sysconfig with atleast one MPU region for L3_BANK_A
        * If app-image if not encrypted, "Decrypt Application Image" can be unchecked in sysconfig, and SET FIREWALL instances can be removed to reduce sbl size
        */
        if((TRUE == Bootloader_socIsAuthRequired()) &&
           (TRUE == gBootloaderConfig[CONFIG_BOOTLOADER0].isAppimageEncrypted) &&
           (TRUE == gBootloaderConfig[CONFIG_BOOTLOADER0].isAppimageSigned) &&
           (FALSE == gBootloaderConfig[CONFIG_BOOTLOADER0].disableAppImageAuth))
        {
            for(fwCtr = 0U; fwCtr<FIREWALL_ARRAY0_NUM_REGIONS; fwCtr++)
            {
                if(gMpuFirewallRegionConfig_0[fwCtr].firewallId == CSL_FW_L3_BANKA_ID)
                {
                    decryptAppImage = TRUE;
                    break;
                }
            }
        }

        if(decryptAppImage == TRUE)
        {
            /* Initialize L3 RAM memory- this is used as space to decrypt encrypted appimage */
            SOC_rcmStartMemInitDSSL3(SOC_RCM_MEMINIT_DSSL3_MEMBANK_ALL);
            SOC_rcmWaitMemInitDSSL3(SOC_RCM_MEMINIT_DSSL3_MEMBANK_ALL);
            gIsL3MemInitDone = TRUE;

            /* Register HSM Client with FW_CLIENT_ID to update L3 RAM MPU firewall settings */
            status = HsmClient_register(&gFwClient,FW_CLIENT_ID);
            DebugP_assert(status == SystemP_SUCCESS);

            /* Get original MPU firewall configs for L3 RAM memory */
            SblQspi_getL3MpuConfig();

            /* Update MPU firewall config */
            SblQspi_updateL3MpuConfig();
        }
#else
        /* Ensure isAppimageEncrypted is set to FALSE as decryption is not supported without L3 RAM MPU Firewall re-config*/
        gBootloaderConfig[CONFIG_BOOTLOADER0].isAppimageEncrypted = FALSE;
#endif

        bootHandle = Bootloader_open(CONFIG_BOOTLOADER0, &bootParams);

        if(bootHandle != NULL)
        {
            status = Bootloader_parseMultiCoreAppImage(bootHandle, &bootImageInfo);

            /* Load CPUs */
            if((status == SystemP_SUCCESS) && (TRUE == Bootloader_isCorePresent(bootHandle, CSL_CORE_ID_RSS_R4)))
            {
                bootImageInfo.cpuInfo[CSL_CORE_ID_RSS_R4].clkHz = Bootloader_socCpuGetClkDefault(CSL_CORE_ID_RSS_R4);
                Bootloader_profileAddCore(CSL_CORE_ID_RSS_R4);
                status = Bootloader_loadCpu(bootHandle, &bootImageInfo.cpuInfo[CSL_CORE_ID_RSS_R4]);
            }
            if((status == SystemP_SUCCESS) && (TRUE == Bootloader_isCorePresent(bootHandle, CSL_CORE_ID_C66SS0)))
            {
                bootImageInfo.cpuInfo[CSL_CORE_ID_C66SS0].clkHz = Bootloader_socCpuGetClkDefault(CSL_CORE_ID_C66SS0);
                Bootloader_profileAddCore(CSL_CORE_ID_C66SS0);
                status = Bootloader_loadCpu(bootHandle, &bootImageInfo.cpuInfo[CSL_CORE_ID_C66SS0]);
            }
            if ((status == SystemP_SUCCESS) && (TRUE == Bootloader_isCorePresent(bootHandle, CSL_CORE_ID_R5FSS0_1)))
            {
                bootImageInfo.cpuInfo[CSL_CORE_ID_R5FSS0_1].clkHz = Bootloader_socCpuGetClkDefault(CSL_CORE_ID_R5FSS0_1);
                Bootloader_profileAddCore(CSL_CORE_ID_R5FSS0_1);
                status = Bootloader_loadCpu(bootHandle, &bootImageInfo.cpuInfo[CSL_CORE_ID_R5FSS0_1]);
            }
            if((status == SystemP_SUCCESS) && (TRUE == Bootloader_isCorePresent(bootHandle, CSL_CORE_ID_R5FSS0_0)))
            {
                bootImageInfo.cpuInfo[CSL_CORE_ID_R5FSS0_0].clkHz = Bootloader_socCpuGetClkDefault(CSL_CORE_ID_R5FSS0_0);
                Bootloader_profileAddCore(CSL_CORE_ID_R5FSS0_0);
                /* Skip the image load by passing TRUE, so that image load on self core doesnt corrupt the SBLs IVT. Load the image later before the reset release of the self core  */
                status = Bootloader_loadSelfCpu(bootHandle, &bootImageInfo.cpuInfo[CSL_CORE_ID_R5FSS0_0], TRUE);
            }
            Bootloader_profileAddProfilePoint("CPU load");
            Bootloader_profileUpdateAppimageSize(Bootloader_getMulticoreImageSize(bootHandle));
            QSPI_Handle qspiHandle = QSPI_getHandle(CONFIG_QSPI0);
            Bootloader_profileUpdateMediaAndClk(BOOTLOADER_MEDIA_FLASH, QSPI_getInputClk(qspiHandle));

            if(status == SystemP_SUCCESS)
            {
                Bootloader_profileAddProfilePoint("SBL End");
                Bootloader_profilePrintProfileLog();
                DebugP_log("Image loading done, switching to application ...\r\n");
                UART_flushTxFifo(gUartHandle[CONFIG_UART0]);
            }

#if defined FIREWALL_ARRAY0_NUM_REGIONS
            if((decryptAppImage == TRUE) && (FALSE == Bootloader_isCorePresent(bootHandle, CSL_CORE_ID_R5FSS0_0)))
            {
                /* Clear the L3 RAM and restore the L3 RAM MPU firewall configuration, also unregister the HSM FW client id*/
                SblQspi_resetL3Banks();
            }
#endif

            /* Run CPUs */
            if((status == SystemP_SUCCESS) && (TRUE == Bootloader_isCorePresent(bootHandle, CSL_CORE_ID_RSS_R4)))
            {
                status = Bootloader_runCpu(bootHandle, &bootImageInfo.cpuInfo[CSL_CORE_ID_RSS_R4]);
                Bootloader_socConfigurePllPostApllSwitch();
            }
            if((status == SystemP_SUCCESS) && (TRUE == Bootloader_isCorePresent(bootHandle, CSL_CORE_ID_C66SS0)))
            {
                status = Bootloader_runCpu(bootHandle, &bootImageInfo.cpuInfo[CSL_CORE_ID_C66SS0]);
            }
            if((status == SystemP_SUCCESS) && (TRUE == Bootloader_isCorePresent(bootHandle, CSL_CORE_ID_R5FSS0_1)))
            {
                status = Bootloader_runCpu(bootHandle, &bootImageInfo.cpuInfo[CSL_CORE_ID_R5FSS0_1]);
            }

            /*
             * Check if RSS_R4 firmware is booted successfully.
             * RSS_R4 boot sequence doesnot have any impact on loading and unhalting of other cores (C666SS0, R5FSS0_0 and R5FSS0_1)
             * To reduce SBL power-Up time checking of RSS_R4 firmware boot success should be done just before unhalting R5FSS0_0 / R5FSS0_1.
             */
            if((status == SystemP_SUCCESS) && (TRUE == Bootloader_isCorePresent(bootHandle, CSL_CORE_ID_RSS_R4)))
            {
                SOC_rcmWaitBSSBootComplete();
            }

            if((TRUE == Bootloader_isCorePresent(bootHandle, CSL_CORE_ID_R5FSS0_0)) ||
                (TRUE == Bootloader_isCorePresent(bootHandle, CSL_CORE_ID_R5FSS0_1)))
            {
                /* Load the image on self core now */
                if( bootImageInfo.cpuInfo[CSL_CORE_ID_R5FSS0_0].rprcOffset != BOOTLOADER_INVALID_ID)
                {
                    status = Bootloader_rprcImageLoad(bootHandle, &bootImageInfo.cpuInfo[CSL_CORE_ID_R5FSS0_0]);
                }

#if defined FIREWALL_ARRAY0_NUM_REGIONS
               if(decryptAppImage == TRUE)
               {
                    /* Clear the L3 RAM and restore the L3 RAM MPU firewall configuration, also unregister the HSM FW client id*/
                    SblQspi_resetL3Banks();
                }
#endif
                /* If any of the R5 core 0 /core 1 have valid image reset the R5 core. */
                DebugP_assert(status == SystemP_SUCCESS);
                status = Bootloader_runSelfCpu(bootHandle, &bootImageInfo);
            }

            /* it should not return here, if it does, then there was some error */
            Bootloader_close(bootHandle);
        }
    }
    if(status != SystemP_SUCCESS )
    {
        /*Reset and clear L3 RAM memory*/
        HW_WR_REG32((CSL_DSS_CTRL_U_BASE + CSL_DSS_CTRL_DSS_L3RAM_MEMINIT_START), 0xFU);
        DebugP_log("Some tests have failed!!\r\n");
    }
    Drivers_close();
    System_deinit();

    return 0;
}
